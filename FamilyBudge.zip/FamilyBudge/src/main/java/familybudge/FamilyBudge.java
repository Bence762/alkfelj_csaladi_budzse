package familybudge;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

@SpringBootApplication
public class FamilyBudge extends WebMvcConfigurerAdapter {
	
	 public static void main(String[] args) {
            SpringApplication.run(FamilyBudge.class, args);
    }	
}