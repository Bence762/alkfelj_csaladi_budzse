package familybudge.service;

import org.springframework.stereotype.Service;
import org.springframework.web.context.annotation.SessionScope;

@Service
@SessionScope
public class UserService{
	
	private User user;
	
	@Autowired
    private UserRepository userRepository;
	
	public User register(User user) {
        user.setRole(User.Role.USER);
        return this.user = userRepository.save(user);
    }
	
	public boolean isLoggedIn() {
        return user != null;
    }
    
    public User getLoggedInUser() {
        return user;
    }
    
    public void logout() {
        user = null;
    }
	
}